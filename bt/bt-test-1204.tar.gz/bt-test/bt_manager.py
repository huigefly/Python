"""
Created on 2019.11.08
@author: zhengfh
"""

from bt_base import BtBase
from common.bt_const import *
from common.file import File
from common.tool import shell_command
import libtorrent as lt
import json
import os.path
import signal
import time
import mmap
import sys

g_bm = None


def signal_handle(sig, stack):
    g_bm.stop()
    os._exit(0)


class BtManager(BtBase):
    def __init__(self):
        self.__block_size = 256 * 1024
        self.__download_rate_limit = -1
        self.__upload_rate_limit = -1
        self.__base_total_size = 0
        self.__basename = ""
        self.__save_dir_abspath = ""
        self.__base_abspath = ""
        self.__torrent_abspath = ""
        self.__state_str = ['queued', 'checking', 'downloading metadata', \
                            'downloading', 'finished', 'seeding', \
                            'allocating', 'checking fastresume']

    def start(self, save_dir_abspath, torrent_abspath, download_rate=-1, upload_rate=-1):
        self.__save_dir_abspath = save_dir_abspath
        self.__torrent_abspath = torrent_abspath
        if int(download_rate) > 0:
            self.__download_rate_limit = int(download_rate) * 1024
        if int(upload_rate) > 0:
            self.__upload_rate_limit = int(upload_rate) * 1024

        self.__set_session()
        self.__add_torrent(torrent_abspath, save_dir_abspath)
        self.__run()
        self.__create_fastresume(save_dir_abspath)
        # os._exit(0)
        return 0

    def status(self, base_abspath):
        basename = os.path.basename(base_abspath)
        logpath = SUPERVISOR_PROG_LOG_FORMAT % basename
        cmd = "cat %s%s|grep {.*status.*name.*|tail -n 1" % (LOG_PATH, logpath)
        status, output = shell_command(cmd, need_out=True)
        if StatusCode.SUCCESS != status:
            print("exec failed cmd:%s" % cmd)

        if len(output) == 0:
            init_status = {'status': 'queued', 'download_size': '0', 'name': basename, 'total_size': '0',
                           'upload_speed': '0', 'download_speed': '0', 'progress': "%.2f" % 0}
            output = json.dumps(init_status)
        return output.strip("\n")

    def stop(self):
        if self.__ses:
            self.__ses.pause()

        if self.__handle:
            s = self.__handle.status()
            print(self.__get_download_status(s, "stop"))

    def delete_diff(self, diff_file_abspath):
        if not File.exist(diff_file_abspath):
            return StatusCode.SUCCESS

        if StatusCode.SUCCESS == File.delete(diff_file_abspath):
            return StatusCode.SUCCESS

        return StatusCode.FAILED

    def diff_size(self, new_torrent_abspath, old_torrent_abspath):
        diff_size = 0
        new_torrent = self.__lt_get_torrent_info(new_torrent_abspath)
        old_torrent = self.__lt_get_torrent_info(old_torrent_abspath)
        new_num_pieces = new_torrent.num_pieces()
        pre_num_pieces = old_torrent.num_pieces()
        for i in range(new_num_pieces):
            m_hash = new_torrent.hash_for_piece(i)
            if i < pre_num_pieces:
                pre_hash = old_torrent.hash_for_piece(i)
                if m_hash != pre_hash:
                    diff_size = diff_size + new_torrent.piece_size(i)
            else:
                diff_size = diff_size + new_torrent.piece_size(i)
        return diff_size

    def diff_start(self, new_torrent_abspath, old_torrent_abspath, diff_dir_abspath):
        self.__save_dir_abspath = diff_dir_abspath
        self.__torrent_abspath = new_torrent_abspath

        self.__set_session()
        self.__add_torrent(new_torrent_abspath, diff_dir_abspath)
        rtn = self.__set_handle_diff_pieces(new_torrent_abspath, old_torrent_abspath)
        if StatusCode.NEW_OLD_TORRENT_NO_DIFF == rtn or StatusCode.GET_TORRENT_INFO_ERROR == rtn:
            return rtn
        self.__run()
        self.__create_fastresume(diff_dir_abspath)
        return StatusCode.SUCCESS

    def merge(self, base_abspath, diff_file_abspath):
        # get diff pieces index
        diff_pieces_index = self.__get_diff_pieces_index(diff_file_abspath)
        merge_pieces = []
        for piece in diff_pieces_index.split("\n"):
            if len(piece) > 0:
                merge_pieces.append(int(piece))

        # resize base file
        diff_file_size = File.get_size(diff_file_abspath)
        base_file_size = File.get_size(base_abspath)
        if diff_file_size != base_file_size:
            File.ftruncate(base_abspath, diff_file_size)

        # open mmap
        fd_diff = open(diff_file_abspath, "r")
        fd_base = open(base_abspath, "a+")
        m = mmap.mmap(fd_base.fileno(), 0, access=mmap.ACCESS_WRITE)

        # start merge
        i = 0
        rtn = StatusCode.SUCCESS
        len_piece = len(merge_pieces)
        basename = os.path.basename(base_abspath)
        status = {'status': 'merge', 'download_size': '0', 'name': basename, 'total_size': '0',
                    'upload_speed': '0', 'download_speed': '0', 'progress': 0.0}
        for merge_piece in merge_pieces:
            if StatusCode.SUCCESS != self.__merge(merge_piece, fd_diff, m):
                rtn = StatusCode.FAILED
                break
            i = i + 1.0
            progress = (i / len_piece) * 100.0
            if progress == 100.00:
                break
            status['progress'] = "%.2f" % progress
            print(json.dumps(status))

        # sync
        m.flush()
        fd_diff.close()
        fd_base.close()
        status['progress'] = "%.2f" % 100.00
        print(json.dumps(status))
        return rtn

    def get_torrent_info(self, torrent_abspath):
        content = {}
        try:
            fd = open(torrent_abspath, 'rb')
            torrent_data = lt.bdecode(fd.read())
            torrent_info = lt.torrent_info(torrent_data)
            fd.close()
            content["info_hash"] = torrent_info.info_hash()
            content["announce"] = torrent_data['announce']
            content["name"] = torrent_info.name()
        except:
            return StatusCode.GET_TORRENT_INFO_ERROR
        return content

    def __set_session(self):
        settings = lt.session_settings()
        settings.user_agent = 'python_client/' + lt.version
        settings.ignore_limits_on_local_network = False
        self.__ses = lt.session()
        self.__ses.listen_on(BT_SHARE_PORT, BT_SHARE_PORT + 300)
        self.__ses.set_settings(settings)
        self.__ses.set_alert_mask(lt.alert.category_t.tracker_notification)

    def __add_torrent(self, torrent_abspath, save_abspath):
        atp = {}
        atp["save_path"] = save_abspath
        atp["storage_mode"] = lt.storage_mode_t.storage_mode_sparse
        atp["paused"] = False
        atp["auto_managed"] = True
        atp["duplicate_is_error"] = True
        info = self.__lt_get_torrent_info(torrent_abspath)
        self.__basename = info.name()
        print('download add: \'%s\'...' % self.__basename)
        self.__base_abspath = self.__save_dir_abspath + "/" + self.__basename
        self.__base_total_size = info.total_size()
        try:
            fast_resume = os.path.join(save_abspath, self.__basename + '.fastresume')
            if File.exist(fast_resume):
                atp["resume_data"] = open(fast_resume, 'rb').read()
        except:
            pass
        atp["ti"] = info
        self.__handle = self.__ses.add_torrent(atp)
        self.__handle.set_max_connections(60)
        self.__handle.set_max_uploads(-1)
        self.__handle.set_download_limit(self.__download_rate_limit)
        self.__handle.set_upload_limit(self.__upload_rate_limit)
        return self.__handle

    def __run(self):
        print("downloading: %s" % self.__base_abspath)
        while True:
            s = self.__handle.status()
            download_status = self.__get_download_status(s, self.__state_str[s.state])
            if s.state == lt.torrent_status.seeding or s.state == lt.torrent_status.finished:
                print(download_status)
                break

            print(download_status)
            time.sleep(0.5)
        self.__ses.pause()

    def __set_handle_diff_pieces(self, new_torrent_abspath, old_torrent_abspath):
        rtn_flag = StatusCode.NEW_OLD_TORRENT_NO_DIFF
        self.__handle.pause()
        new_torrent = self.__lt_get_torrent_info(new_torrent_abspath)
        old_torrent = self.__lt_get_torrent_info(old_torrent_abspath)
        num_pieces = new_torrent.num_pieces()
        pre_num_pieces = old_torrent.num_pieces()
        # print('Compare pieces:{new}, pre pieces:{old}'.format(new=num_pieces, old=pre_num_pieces))
        for i in range(num_pieces):
            m_hash = new_torrent.hash_for_piece(i)

            if i < pre_num_pieces:
                pre_hash = old_torrent.hash_for_piece(i)
                if m_hash == pre_hash:
                    # print 'skip piece {i}'.format(i=i)
                    self.__handle.piece_priority(i, TORRENT_PIECE_IGNORE)
                else:
                    print('download piece {i}'.format(i=i))
                    rtn_flag = StatusCode.NEW_OLD_TORRENT_HAVE_DIFF
                    self.__handle.piece_priority(i, TORRENT_PIECE_NEED_DOWNLOAD)
            else:
                print('download piece {i}'.format(i=i))
                rtn_flag = StatusCode.NEW_OLD_TORRENT_HAVE_DIFF
                self.__handle.piece_priority(i, TORRENT_PIECE_NEED_DOWNLOAD)
        self.__handle.resume()
        return rtn_flag

    def __lt_get_torrent_info(self, torrent_abspath):
        try:
            fd = open(torrent_abspath, 'rb')
            torrent_data = lt.bdecode(fd.read())
            torrent = lt.torrent_info(torrent_data)
            fd.close()
            return torrent
        except Exception as ex:
            print("torrent info error: %s\nstatck msg:%s" % (torrent_abspath, ex))
            os._exit(StatusCode.GET_TORRENT_INFO_ERROR)

    def __get_download_status(self, s, download_status_flag):
        download_status = {}
        download_status["status"] = download_status_flag
        download_status["name"] = self.__basename
        download_status["progress"] = "%.2f" % (s.progress * 100)
        download_status["download_speed"] = self.__add_suffix(s.download_rate)
        download_status["upload_speed"] = self.__add_suffix(s.upload_rate)
        download_status["total_size"] = self.__add_suffix(self.__base_total_size)
        download_status["download_size"] = self.__add_suffix(s.total_done)
        return json.dumps(download_status)

    def __add_suffix(self, val):
        prefix = ['B', 'kB', 'MB', 'GB', 'TB']
        for i in range(len(prefix)):
            if abs(val) < 1000:
                if i == 0:
                    return '%.3g%s' % (val, prefix[i])
                else:
                    return '%.3g%s' % (val, prefix[i])
            val /= 1000.0

        return '%6.3gPB' % val

    def __create_fastresume(self, save_abspath):
        if self.__handle.is_valid() and self.__handle.has_metadata():
            data = lt.bencode(self.__handle.write_resume_data())
            open(os.path.join(save_abspath, self.__handle.get_torrent_info().name() + '.fastresume'), 'wb').write(data)

    def __get_diff_pieces_index(self, base_abspath):
        logname = SUPERVISOR_PROG_LOG_FORMAT % os.path.basename(base_abspath)
        cmd = "cat %s/%s |grep 'download piece'|cut -f3 -d' '" % (LOG_PATH, logname)
        status, output = shell_command(cmd, need_out=True)
        if StatusCode.SUCCESS != status:
            print("exec failed cmd:%s" % cmd)
        return output

    def __merge(self, merge_piece, fd_diff, m):
        try:
            fd_diff.seek(merge_piece * self.__block_size, 0)
            diff_block = fd_diff.read(self.__block_size)
            m.seek(merge_piece * self.__block_size)
            if diff_block:
                m.write(diff_block)
            return StatusCode.SUCCESS
        except:
            return StatusCode.FAILED


if __name__ == "__main__":
    # set signal handle
    signal.signal(signal.SIGTERM, signal_handle)

    if len(sys.argv) >= 4 and "start" == sys.argv[1]:
        download_rate = -1
        upload_rate = -1
        g_bm = BtManager()
        if len(sys.argv) >= 5 and sys.argv[4]:
            download_rate = sys.argv[4]
        if len(sys.argv) >= 6 and sys.argv[5]:
            upload_rate = sys.argv[5]
        g_bm.start(sys.argv[2], sys.argv[3], download_rate, upload_rate)
    elif len(sys.argv) == 5 and "diff_start" == sys.argv[1]:
        g_bm = BtManager()
        g_bm.diff_start(sys.argv[2], sys.argv[3], sys.argv[4])
    elif len(sys.argv) == 4 and "merge" == sys.argv[1]:
        g_bm = BtManager()
        g_bm.merge(sys.argv[2], sys.argv[3])
    else:
        print("usage:" + "\n" + \
              "\tbt_manager.py start save_abspath torrent_abspath download_rate upload_rate\n" + \
              "\tbt_manager.py diff_start torrent_abspath old_torrent_abspath diff_abspath \n" + \
              "\tbt_manager.py merge save_abspath diff_abspath \n" + \
              "\tbt_manager.py stop")

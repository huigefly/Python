"""
Created on 2019.11.08
@author: zhengfh
"""

import os


class Dir:

    @classmethod
    def exist(cls, dir_path):
        return os.path.isdir(dir_path)

    @classmethod
    def create(cls, dir_path):
        if not os.path.isdir(dir_path):
            return os.mkdir(dir_path)

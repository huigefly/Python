'''
Created on 2019.11.08
@author: zhengfh
'''

BT_SHARE_PORT = 6881
TORRENT_PIECE_IGNORE = 0
TORRENT_PIECE_NEED_DOWNLOAD = 7

LOG_PATH = "/var/log/"
BT_PROXY_LOG = "bt_proxy.log"
BT_PATH = "/opt/work/code/bt-test/"
SUPERVISOR_CONF_DIR_PATH = "/etc/supervisor/conf.d/"
SUPERVISOR_PROG_CONF_FORMAT = "Images_%s.conf"
SUPERVISOR_PROG_NAME_FORMAT = "sharebt_%s"
SUPERVISOR_PROG_MERGE_CONF_FORMAT = "Images_merge_%s.conf"
SUPERVISOR_PROG_MERGE_NAME_FORMAT = "sharebt_merge_%s"
SUPERVISOR_PROG_LOG_FORMAT = "Images_%s_stdout.log"


class StatusCode:
    _list = [''] * 15

    SUCCESS = 0
    _list[SUCCESS] = "success"

    FAILED = 1
    _list[FAILED] = "failed"

    TORRENT_NO_EXIST = 2
    _list[TORRENT_NO_EXIST] = "torrent file not exist"

    ERROR_INPUT_FLAG = 3
    _list[ERROR_INPUT_FLAG] = "supervisor program is already existed, already started"

    ERROR_INPUT_TORRENT = 4
    _list[ERROR_INPUT_TORRENT] = "torrent info no annouce"

    ERROR_CREATE_BT_SUPERVISOR_CONF = 5
    _list[ERROR_CREATE_BT_SUPERVISOR_CONF] = "supervisor create program conf error"

    BASE_NO_EXIST = 6
    _list[BASE_NO_EXIST] = "base file not exist"

    NEW_OLD_TORRENT_NO_DIFF = 7
    _list[NEW_OLD_TORRENT_NO_DIFF] = "new old torrent no diff"

    NEW_OLD_TORRENT_HAVE_DIFF = 8
    _list[NEW_OLD_TORRENT_HAVE_DIFF] = "new old torrent have diff"

    TASK_NO_EXIST = 9
    _list[TASK_NO_EXIST] = "task no exist"

    DELETE_FILE_FAILED = 10
    _list[DELETE_FILE_FAILED] = "delete file failed"

    OLD_TORRENT_NO_EXIST = 11
    _list[OLD_TORRENT_NO_EXIST] = "old torrent file no exist"

    NEW_TORRENT_NO_EXIST = 12
    _list[NEW_TORRENT_NO_EXIST] = "new torrent file no exist"

    DIFF_FILE_NO_EXIST = 13
    _list[DIFF_FILE_NO_EXIST] = "diff file no exist"

    GET_TORRENT_INFO_ERROR = 14
    _list[GET_TORRENT_INFO_ERROR] = "get torrent info error"
    
"""
Created on 2019.11.08
@author: zhengfh
"""

from bt_const import *
from common.tool import shell_command


class Supervisor(object):

    @classmethod
    def is_ser_running(cls):
        return cls.__exec("service supervisor status | grep -q \"Active: active (running)\" > /dev/null")

    @classmethod
    def start_ser(cls):
        return cls.__exec("service supervisor start > /dev/null")

    @classmethod
    def stop_ser(cls):
        return cls.__exec("service supervisor stop > /dev/null")

    @classmethod
    def is_program_running(cls, program_name):
        cmd = "supervisorctl status %s | grep -q  RUNNING > /dev/null" % program_name
        return cls.__exec(cmd)

    @classmethod
    def start_program(cls, program_name):
        cmd = "supervisorctl start %s  > /dev/null &" % program_name
        return cls.__exec(cmd)

    @classmethod
    def stop_program(cls, program_name):
        cmd = "supervisorctl stop %s  > /dev/null" % program_name
        return cls.__exec(cmd)

    @classmethod
    def update_program_conf(cls, program_name):
        cmd = "supervisorctl reread > /dev/null; supervisorctl update %s > /dev/null" % program_name
        return cls.__exec(cmd)

    @classmethod
    def delete_prog_all_conf(cls):
        cmd = "rm -rf %s/*" % SUPERVISOR_CONF_DIR_PATH
        return cls.__exec(cmd)

    @classmethod
    def delete_prog_conf(cls, filepath):
        cmd = "rm -rf %s/%s" % (SUPERVISOR_CONF_DIR_PATH, filepath)
        return cls.__exec(cmd)

    @classmethod
    def create_program_conf(cls, sv_prog_name, log_name, sv_cmd, filepath):
        content = ("[program:%s]\n"
                   + "command=%s\n"
                   + "redirect_stderr = true \n"
                   + "autostart=false \n"
                   + "directory=%s\n"
                   + "exitcodes=0\n"
                   + "startretries=0\n"
                   + "stdout_logfile_maxbytes = 50MB \n"
                   + "stdout_logfile_backups = 0 \n"
                   + "stdout_logfile = %s/%s \n") % (sv_prog_name, sv_cmd, BT_PATH, LOG_PATH, log_name)

        try:
            f = open(filepath, "w+")
            f.writelines(content)
            f.close()
            return StatusCode.SUCCESS
        except:
            return StatusCode.FAILED

    @staticmethod
    def __exec(cmd):
        return shell_command(cmd)

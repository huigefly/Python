"""
Created on 2019.11.21
@author: zhengfh
"""

from subprocess import Popen, STDOUT
import tempfile


def shell_command(cmd, need_out=False):
    returncode = 0
    out = ""
    if need_out:
        try:
            out_temp = None
            out_temp = tempfile.SpooledTemporaryFile(bufsize=4096)
            fileno = out_temp.fileno()
            child = Popen(cmd, shell=True, close_fds=True, stdout=fileno, stderr=fileno)
            child.wait()
            out_temp.seek(0)
            out = out_temp.read()
            returncode = child.returncode
        except Exception as e:
            raise
            logger.warn("%s" % (e))
        finally:
            if out_temp:
                out_temp.close()
    else:
        child = Popen(cmd, shell=True, close_fds=True,
                      stdout=open("/dev/null", "w"), stderr=STDOUT)
        child.wait()
        returncode = child.returncode

    try:
        if child.stdin:
            child.stdin.close()
        if child.stdout:
            child.stdout.close()
        if child.stderr:
            child.stderr.close()
        child.kill()
    except Exception as e:
        pass

    if need_out:
        return returncode, out.strip()
    else:
        return returncode

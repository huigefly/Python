"""
Created on 2019.11.08
@author: zhengfh
"""

import os


class File:

    @classmethod
    def exist(cls, file_path):
        return os.path.isfile(file_path)

    @classmethod
    def create(cls, file_path):
        f = open(file_path, "w")
        f.close()

    @classmethod
    def delete(cls, file_path):
        if os.path.isfile(file_path):
            try:
                os.remove(file_path)
            except:
                return -1
            return 0
        return -1

    @classmethod
    def get_size(cls, file_path):
        if os.path.isfile(file_path):
            return os.path.getsize(file_path)
        return -1

    @classmethod
    def truncate(cls, file_path):
        if os.path.isfile(file_path):
            f = open(file_path, "w")
            f.truncate()
            f.close()

    @classmethod
    def ftruncate(cls, file_path, size):
        if os.path.isfile(file_path):
            fd = os.open(file_path, os.O_RDWR)
            os.ftruncate(fd, size)
            os.close(fd)

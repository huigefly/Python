#!/bin/bash

#usage:
#        bt_proxy.py start save_abspath torrent_abspath
#        bt_proxy.py status base_abspath
#        bt_proxy.py diff_size new_torrent_abspath old_torrent_abspath
#        bt_proxy.py diff_start new_torrent_abspath old_torrent_abspath base_abspath diff_abspath
#        bt_proxy.py merge base_abspath diff_file_abspath
#        bt_proxy.py stop base_abspath bool_clear

image_name=hello_157.base
proj_dir=/opt/work/code/bt-test/
bt_proxy=$proj_dir/bt_proxy.py
test_torrent_file=/opt/work/package/$image_name.torrent
test_new_torrent_file=/opt/work/package/newtorrent/$image_name.torrent
new_image=/opt/work/package/newtorrent/$image_name
src_image=/opt/work/package/$image_name
bt_seeding_dir=/opt/work/package/
save_dir=/mydir/save
diff_dir=/mydir/diff
diff_image=$diff_dir/$image_name
base_path=$save_dir/$image_name
maketorrent=/opt/work/package/BitTorrent-4.0.3/btmaketorrent.py
tracker_server=http://192.168.65.128:1337/announce
# runcmd="coverage run -a"
runcmd="python"

start(){
  echo start download $test_torrent_file, save to $save_dir
  $runcmd $bt_proxy start $save_dir $test_torrent_file
  echo start download end
  echo
}

status(){
  echo check download status. base_path:$1
  $runcmd $bt_proxy status $1
  echo check download end
  echo
}

stop(){
  echo stop download
  echo base_path:$base_path
  $runcmd $bt_proxy stop $base_path $1
  if [ -f $base_path ]; then
    echo $base_path exist
  else
    echo $base_path is deleted
  fi
  echo stop download end
  echo
}

diff_size(){
  echo diff size calc.
  echo old torrent:$2
  echo new torrent:$1
  $runcmd $bt_proxy diff_size $1 $2
  echo diff size calc end
  echo
}

diff_start(){
  echo diff start download
  $runcmd $bt_proxy diff_start $1 $2 $base_path $diff_dir
  wait_download_end $diff_image
}

merge(){
  echo merge start
  $runcmd $bt_proxy merge $base_path $diff_image
  echo merge base:$base_path
  while true
  do
    status $base_path|egrep ".*merge.*progress.*100.*" > /dev/null
    if [ $? -eq 0 ];then
        echo merge end
        break
    fi
    sleep 1
  done
  echo
}

wait_download_end(){
  echo wait downloading.....
  while true
  do
    status $1|egrep "seeding|finished" > /dev/null
    if [ $? -eq 0 ]; then
      echo download end
      echo
      break
    fi
    sleep 1
  done
}

check_file_md5(){
  echo check file md5....
  basemd5=`md5sum $1|cut -f1 -d' '`
  srcmd5=`md5sum $2|cut -f1 -d' '`
  echo basemd5:$basemd5
  echo srocmd5:$srcmd5
  if [ "$basemd5" == "$srcmd5" ]; then
    echo download file is right
  fi
}

check_basefile_is_created(){
  echo check $base_path is created......
  while true
  do
    if [ -f $base_path ]; then
      break
    fi
    sleep 1
  done
  echo $base_path is created. 
  echo
}

# test start download, check status, stop and restart, check md5
start
check_basefile_is_created
status $base_path
stop true
status $base_path
sleep 1
start
status $base_path
stop false
status $base_path
start
check_basefile_is_created
status $base_path
wait_download_end $base_path
check_file_md5 $base_path $src_image
echo

# test diff_size
diff_size $test_new_torrent_file $test_torrent_file

# test diff_start
diff_start $test_new_torrent_file $test_torrent_file

# test merge
merge 
check_file_md5 $base_path $new_image

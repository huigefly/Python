"""
Created on 2019.11.08
@author: zhengfh
"""

from abc import ABCMeta, abstractmethod


class BtBase(object):
    __metaclass__ = ABCMeta

    @abstractmethod
    def start(self, save_abspath, torrent_abspath): pass

    @abstractmethod
    def status(self, base_abspath): pass

    @abstractmethod
    def stop(self, base_abspath, bool_clear): pass

    @abstractmethod
    def delete_diff(self, diff_file_abspath): pass

    @abstractmethod
    def diff_size(self, new_torrent_abspath, old_torrent_abspath): pass

    @abstractmethod
    def diff_start(self, new_torrent, old_torrent, base_abspath, diff_path): pass

    @abstractmethod
    def merge(self, base_abspath, diff_file_abspath): pass

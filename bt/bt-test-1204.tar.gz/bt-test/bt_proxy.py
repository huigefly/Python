"""
Created on 2019.11.08
@author: zhengfh
"""

from bt_base import BtBase
from common.file import File
from common.dir import Dir
from common.bt_const import *
from common.supervisor import Supervisor
from bt_manager import BtManager
import hashlib
import sys
import os
import time
import json


class BtProxy(BtBase):

    def __init__(self):
        self.__basename = ""
        self.__bm = BtManager()
        self.__fd = open(os.path.join(LOG_PATH, BT_PROXY_LOG), "a+")

    def __del__(self):
        if self.__fd:
            self.__fd.close()

    def start(self, save_abspath, torrent_abspath, download_rate = -1, upload_rate = -1):
        # check file and dir
        if not File.exist(torrent_abspath):
            return self.__exit_message(StatusCode.TORRENT_NO_EXIST)
        Dir.create(save_abspath)

        # start handle
        sv_cmd = "python -u bt_manager.py start %s %s %s %s" % (save_abspath, torrent_abspath, download_rate, upload_rate)
        rtn = self.__start_proc(torrent_abspath, save_abspath, sv_cmd)

        # exit and return message
        self.__exit_message(rtn)

    def status(self, base_abspath):
        # if not File.exist(base_abspath):
        #     return self.__exit_message(StatusCode.BASE_NO_EXIST)
        self.__log(self.__bm.status(base_abspath))

    def stop(self, base_abspath, bool_clear):
        sv_prog_name = SUPERVISOR_PROG_NAME_FORMAT % hashlib.md5(os.path.basename(base_abspath)).hexdigest()
        if StatusCode.SUCCESS != Supervisor.stop_program(sv_prog_name):
            return self.__exit_message(StatusCode.FAILED)

        if bool_clear.lower() == "true" and File.exist(base_abspath):
            if StatusCode.SUCCESS != File.delete(base_abspath):
                return self.__exit_message(StatusCode.DELETE_FILE_FAILED)

        self.__exit_message(StatusCode.SUCCESS)

    def delete_diff(self, diff_file_abspath):
        rtn = self.__bm.delete_diff(diff_file_abspath)
        self.__exit_message(rtn)

    def diff_size(self, new_torrent_abspath, old_torrent_abspath):
        if not File.exist(new_torrent_abspath):
            return self.__exit_message(StatusCode.NEW_TORRENT_NO_EXIST)

        if not File.exist(old_torrent_abspath):
            return self.__exit_message(StatusCode.OLD_TORRENT_NO_EXIST)

        size = self.__bm.diff_size(new_torrent_abspath, old_torrent_abspath) / 1024
        self.__exit_message(StatusCode.SUCCESS, size)

    def diff_start(self, new_torrent_abspath, old_torrent_abspath, base_abspath, diff_dir_abspath):
        if not File.exist(new_torrent_abspath) or not File.exist(old_torrent_abspath):
            return self.__exit_message(StatusCode.TORRENT_NO_EXIST)

        if not File.exist(base_abspath):
            return self.__exit_message(StatusCode.BASE_NO_EXIST)
        Dir.create(diff_dir_abspath)

        sv_cmd = "python -u bt_manager.py diff_start %s %s %s" % (
                new_torrent_abspath, old_torrent_abspath, diff_dir_abspath)
        rtn = self.__start_proc(new_torrent_abspath, diff_dir_abspath, sv_cmd)
        self.__exit_message(rtn)

    def merge(self, base_abspath, diff_file_abspath):
        # check file exist
        if not File.exist(base_abspath):
            return self.__exit_message(StatusCode.BASE_NO_EXIST)

        if not File.exist(diff_file_abspath):
            return self.__exit_message(StatusCode.DIFF_FILE_NO_EXIST)

        # create supervisor config
        sv_cmd="python -u bt_manager.py merge %s %s" % (base_abspath, diff_file_abspath)
        rtn = self.__merge_proc(base_abspath, diff_file_abspath, sv_cmd)
        # rtn = self.__bm.merge(base_abspath, diff_file_abspath)
        self.__exit_message(rtn)

    def __merge_proc(self, base_abspath, diff_file_abspath, sv_cmd):
        rtn = StatusCode.SUCCESS
        basename = os.path.basename(base_abspath)
        sv_prog_conf = SUPERVISOR_PROG_MERGE_CONF_FORMAT % basename
        sv_prog_conf_abspath = SUPERVISOR_CONF_DIR_PATH + sv_prog_conf
        sv_prog_name = SUPERVISOR_PROG_MERGE_NAME_FORMAT % hashlib.md5(basename).hexdigest()
        sv_log_name = SUPERVISOR_PROG_LOG_FORMAT % basename
        if not File.exist(sv_prog_conf_abspath):
            rtn = self.__create_file_and_run(sv_prog_conf_abspath, sv_prog_name, sv_log_name, sv_cmd, False)
        else:
            # check prog status, if running, exit, if not, restart
            if StatusCode.SUCCESS == Supervisor.is_program_running(sv_prog_name):
                return StatusCode.ERROR_INPUT_FLAG
            else:
                Supervisor.delete_prog_conf(sv_prog_conf_abspath)
                Supervisor.update_program_conf(sv_prog_name)
                rtn = self.__create_file_and_run(sv_prog_conf_abspath, sv_prog_name, sv_log_name, sv_cmd, False)
        return rtn

    def __start_proc(self, new_torrent_abspath, diff_dir_abspath, sv_cmd):
        # show torrent file
        rtn = self.__show_torrent_info(new_torrent_abspath, diff_dir_abspath)
        if StatusCode.SUCCESS != rtn:
            return rtn

        # conf no exist, create bt supervisor conf and start
        sv_prog_conf = SUPERVISOR_PROG_CONF_FORMAT % self.__basename
        sv_prog_conf_abspath = SUPERVISOR_CONF_DIR_PATH + sv_prog_conf
        sv_prog_name = SUPERVISOR_PROG_NAME_FORMAT % hashlib.md5(self.__basename).hexdigest()
        sv_log_name = SUPERVISOR_PROG_LOG_FORMAT % self.__basename
        if not File.exist(sv_prog_conf_abspath):
            rtn = self.__create_file_and_run(sv_prog_conf_abspath, sv_prog_name, sv_log_name, sv_cmd)
        else:
            # check prog status, if running, exit, if not, restart
            if StatusCode.SUCCESS == Supervisor.is_program_running(sv_prog_name):
                return StatusCode.ERROR_INPUT_FLAG
            else:
                Supervisor.delete_prog_conf(sv_prog_conf_abspath)
                Supervisor.update_program_conf(sv_prog_name)
                rtn = self.__create_file_and_run(sv_prog_conf_abspath, sv_prog_name, sv_log_name, sv_cmd)
        return rtn

    def __create_bt_supervior_conf(self, sv_prog_conf_abspath, sv_prog_name, log_name, sv_cmd):
        return Supervisor.create_program_conf(sv_prog_name, log_name, sv_cmd, sv_prog_conf_abspath)

    def __show_torrent_info(self, torrent_abspath, save_abspath):
        torrent_info = self.__bm.get_torrent_info(torrent_abspath)
        if StatusCode.GET_TORRENT_INFO_ERROR == torrent_info:
            return StatusCode.GET_TORRENT_INFO_ERROR
        if torrent_info:
            if len(torrent_info["announce"]) <= 0:
                return StatusCode.ERROR_INPUT_TORRENT
            self.__basename = torrent_info["name"]
        return StatusCode.SUCCESS

    def __create_file_and_run(self, sv_prog_conf_abspath, sv_prog_name, sv_log_name, sv_cmd, bool_clear=True):
        # clean old log
        if True == bool_clear:
            File.truncate(LOG_PATH + sv_log_name)

        # create supervisor conf
        if StatusCode.SUCCESS != Supervisor.create_program_conf(sv_prog_name, sv_log_name, sv_cmd,
                                                                sv_prog_conf_abspath):
            return StatusCode.ERROR_CREATE_BT_SUPERVISOR_CONF

        # supervisor operator
        Supervisor.update_program_conf(sv_prog_name)
        Supervisor.start_program(sv_prog_name)
        time.sleep(1)
        return StatusCode.SUCCESS

    def __log(self, info):
        print(info)
        if self.__fd:
            self.__fd.write(info + "\n")

    def __exit_message(self, status_code, size=-1):
        msg = {}
        msg["status"] = status_code
        msg["massage"] = StatusCode._list[status_code]
        if size > -1:
            msg["size"] = size

        self.__log(json.dumps(msg))
        os._exit(status_code)
        # return status_code


if __name__ == "__main__":
    # check supervisord is running
    if StatusCode.SUCCESS != Supervisor.is_ser_running():
        Supervisor.stop_ser()
        Supervisor.delete_prog_all_conf()
        Supervisor.start_ser()

    if len(sys.argv) >= 4 and "start" == sys.argv[1]:
        download_rate = -1
        upload_rate = -1
        bp = BtProxy()
        if len(sys.argv) >= 5 and sys.argv[4]:
            download_rate = sys.argv[4]
        if len(sys.argv) >= 6 and sys.argv[5]:
            upload_rate = sys.argv[5]
        bp.start(sys.argv[2], sys.argv[3], download_rate, upload_rate)
    elif len(sys.argv) == 4 and "stop" == sys.argv[1]:
        bp = BtProxy()
        bp.stop(sys.argv[2], sys.argv[3])
    elif len(sys.argv) == 4 and "diff_size" == sys.argv[1]:
        bp = BtProxy()
        bp.diff_size(sys.argv[2], sys.argv[3])
    elif len(sys.argv) == 3 and "status" == sys.argv[1]:
        bp = BtProxy()
        bp.status(sys.argv[2])
    elif len(sys.argv) == 6 and "diff_start" == sys.argv[1]:
        bp = BtProxy()
        bp.diff_start(sys.argv[2], sys.argv[3], sys.argv[4], sys.argv[5])
    elif len(sys.argv) == 4 and "merge" == sys.argv[1]:
        bp = BtProxy()
        bp.merge(sys.argv[2], sys.argv[3])
    elif len(sys.argv) == 3 and "diff_delete" == sys.argv[1]:
        bp = BtProxy()
        bp.delete_diff(sys.argv[2])
    else:
        print("usage:" + "\n" + \
              "\tbt_proxy.py start save_dir_abspath torrent_abspath [download_rate(kb) upload_rate(kb)]\n" + \
              "\tbt_proxy.py status base_abspath \n" + \
              "\tbt_proxy.py diff_size new_torrent_abspath old_torrent_abspath \n" + \
              "\tbt_proxy.py diff_start new_torrent_abspath old_torrent_abspath base_abspath diff_dir_abspath\n" + \
              "\tbt_proxy.py merge base_abspath diff_file_abspath \n" + \
              "\tbt_proxy.py delete_diff base_path\n" + \
              "\tbt_proxy.py stop base_abspath bool_clear")
